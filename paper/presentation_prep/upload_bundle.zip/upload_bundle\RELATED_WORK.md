# 선행 연구 및 차별점

이 문서는 `papers/` 폴더의 논문 7편이 본 프로젝트에서 갖는 역할과,
각 논문 대비 본 연구의 차별점을 정리한다.
제안서 v3.0 섹션 4의 코드 저장소 버전이다.

> **본 문서의 위치 (2026-05-14 기준)**:
> - 본 문서는 제안서 시점의 선행 연구 7편 + Phase 1~2 시점의 차별점 정리.
> - Phase 3 진입 시 RQ가 "Reward design이 RL 알파의 핵심 채널?"로 재정의됨.
> - **본 문서에 추가로 통합될 학술 인용은 [`study/rl_finance/00_overview.md`](study/rl_finance/00_overview.md) 의 24개 노트** — 특히:
>   - Avellaneda-Stoikov (2008) — 그리드의 학술적 조상 (§2 Background)
>   - Moody & Saffell (2001) — DSR reward (§3.4 Method)
>   - Kahneman & Tversky (1979) — Prospect theory (§3.4 Method)
>   - Ng, Harada, Russell (1999) — Reward shaping (§3.3 Safety)
>   - Schulman et al. (2017) — PPO algorithm (§3.2 Method)
>   - Zhang, Zohren, Roberts (2020) — DRL trading baseline (§2 Background)
> - 단일 기준점: [`PROJECT_GOAL.md`](PROJECT_GOAL.md).

---

## 논문 목록 (`papers/` 폴더)

| 파일명 | 저자·연도 | 핵심 주제 |
|--------|----------|----------|
| `Sun_2023_RL_Quantitative_Trading_Survey.pdf` | Sun et al. (2023) | RL 트레이딩 전반 조망 (ACM Survey) |
| `Liu_2025_RL_Trading_Strategies_Literature_Review.pdf` | Liu H.Y.T. (2025) | 2018~2025년 RL 트레이딩 10편 종합 리뷰 |
| `Liu_2021_Bitcoin_Transaction_Strategy_PPO_LSTM.pdf` | Liu et al. (2021) | PPO + LSTM 가격 예측 → 트레이딩 |
| `Yasin_Gill_2024_RL_Framework_Quantitative_Trading.pdf` | Yasin & Gill (2024) | DQN/PPO/A2C + 기술지표 20개 비교 |
| `Pham_2025_DQN_Bitcoin_Technical_Strategy_Selection.pdf` | Pham et al. (2025) | DQN + 사전 정의 전략 5개 선택 |
| `Bandarupalli_2025_Risk_Aware_DRL_Crypto_Equity_Trading.pdf` | Bandarupalli (2025) | PPO + 변동성 패널티 + 거래비용 |
| `Gort_2022_DRL_Cryptocurrency_Backtest_Overfitting.pdf` | Gort et al. (2022) | DRL 트레이딩 백테스트 과적합 실증 |

---

## 그룹 1 — 분야 배경 논문

기존 방향성 RL 트레이딩의 한계와 본 연구의 필요성을 정당화하는 논문들이다.

### Sun et al. (2023) — ACM Survey

**내용**: DQN·PPO가 전통 전략 대비 우위를 보이나, 해석가능성 부족과
시장 레짐 간 일반화가 분야 전반의 미해결 과제임을 지적.

**본 연구에서의 역할**: 방향성 RL의 구조적 한계를 정의하는 배경 근거.
본 연구는 방향성 예측을 완전히 제거하는 그리드 구조로 이 공백에 접근한다.

---

### Liu H.Y.T. (2025) — 리뷰 논문

**내용**: 2018~2025년 10편 종합. RL이 비정상 시장 적응성에서 우위 확인.
훈련 안정성·샘플 효율성이 실전 적용의 주요 장애물.

**본 연구에서의 역할**: 분야 흐름과 한계를 뒷받침하는 근거.

---

## 그룹 2 — 직접 선행 연구

본 연구의 차별점을 가장 직접적으로 정의하는 논문들이다.

### Liu et al. (2021) — PPO + LSTM

**방법론**: LSTM으로 BTC 가격 예측 → 예측값을 state로 사용 → PPO 트레이딩 결정.

**한계**: 예측 오류가 트레이딩 결정에 그대로 전파되는 2단계 파이프라인.
가격 예측 모델이 틀리면 트레이딩 결정도 틀린다.

**본 연구와의 차별점**:
- 예측 단계 완전 제거. 미래 가격을 예측하지 않는다.
- 방향성 트레이딩 대신 그리드 구조로 변동성 자체에서 수익 추구.

---

### Yasin & Gill (2024) — 기술지표 20개 비교

**방법론**: DQN/PPO/A2C 3개 알고리즘 + 기술지표 20개를 state로 사용한 비교 연구.

**한계**:
- 홀드(Hold) 행동 없음 — 매 스텝 강제 매수/매도.
- 현재 포지션 state 미포함 — 에이전트가 자신의 재무 상태를 모른다.
- 과매매 억제 불가.

**본 연구와의 차별점**:
- 포지션 상태(divergence, holdings_value_ratio, cash_ratio)를 state에 반영.
- 에이전트가 자신의 손익·보유량·여력을 인식하고 행동한다.
- 연속 행동 공간(간격 값)으로 그리드 주문 배치 — 이산 buy/sell/hold가 아님.

---

### Pham et al. (2025) — DQN + 5개 사전 전략 선택

**방법론**: 5개의 사전 정의된 기술적 전략(RSI, MA 등) 중 하나를 매 스텝 선택하는
메타-전략 선택 구조. PCA로 지표를 압축하여 state 입력.

**한계**:
- 매수·매도 조건이 전략 내부에 하드코딩 — 에이전트는 전략을 선택할 뿐,
  전략 자체를 학습하지 않는다.
- PCA 압축으로 원본 지표 의미 손실 → 행동 해석 불가.

**본 연구와의 차별점**:
- 사전 전략 없이 그리드 간격(aggressiveness, profit_target)을 직접 학습.
- state 변수 원형 유지 → 학습 후 "어떤 시장 상태에서 어떤 간격을 선택했는가" 분석 가능.

---

### Bandarupalli (2025) — PPO + 변동성 패널티

**방법론**: PPO + 변동성 패널티(포트폴리오 분산 최소화 항) + 거래비용 패널티.

**한계**:
- 과도한 리스크 패널티가 수익 기회를 억제.
- Val 셋에서 Buy-and-Hold보다 하회하는 결과 보고.

**본 연구와의 차별점**:
- 변동성 패널티 제외. 거래비용 패널티와 사이클 수익 신호만 사용.
- 그리드 트레이딩은 변동성이 클수록 유리한 구조 — 변동성을 억제할 이유가 없다.

---

## 설계 반영 — Gort et al. (2022)

**내용**: DRL 트레이딩 연구 대부분이 단일 검증셋 사용으로 백테스트 과적합이
발생함을 실증.

**설계 반영**:
- 테스트셋(2024.01~)을 학습 전 과정에서 완전 봉인.
- Validation(2023)과 Test(2024~)를 엄격히 분리.
- 다양한 시장 레짐(상승·하락·횡보)을 포함하는 학습 구간 설계.

---

## 핵심 차별점 요약

| 기존 연구 공통점 | 본 연구 |
|----------------|---------|
| 가격 방향 예측 or 지표 신호 기반 방향성 트레이딩 | 방향 예측 없는 비방향성 그리드 트레이딩 |
| 이산 행동 (Buy / Sell / Hold) | 연속 행동 (aggressiveness, profit_target) |
| 기술지표 state (RSI, SMA, BB 등) | 포지션 상태 + 시장 레짐 state |
| 고정 전략 or 전략 선택 | 그리드 간격 직접 학습 |
| 추세 시장에서 유리 | 변동성 시장에서 유리 (방향 무관) |
| 단일 reward (대부분 PnL) | **Reward 변형 4종 비교 (Phase 3 추가)** |

### Phase 3에서 강화된 차별점 (본 논문 메인 contribution)

**"Reward design이 RL 알파의 핵심 채널이다"** 가설을 정식 검증.

| 측면 | 선행 연구 | 본 연구 |
|---|---|---|
| Reward 종류 | 보통 단일 PnL or 변동성 패널티 추가 | **Symmetric / Asymmetric / DSR / Prospect-theoretic 4종 정식 비교** |
| Reward 학술적 출처 | 임의 선택 | 학술 근거 명시 (Moody 2001, Ng 1999, Kahneman 1979) |
| 통계 검증 | 단일 분할 | **CPCV + DSR (Gort 2022, López de Prado 2014)** |
| Sim2Real gap | 무시 또는 한 줄 언급 | Slippage + DR (exp033) |
| 베이스라인 | Buy-Hold + 1~2 변형 | ATR Bayesian-optimized + 7종 변형 |

---

## 베이스라인 설계 근거

ATR이 본 연구의 state에 포함되어 있음에도 ATR 비례 그리드를 베이스라인으로
사용하는 것이 적절한 이유:

> "같은 정보(ATR)를 **규칙으로 고정해서 쓰는 것** vs **학습으로 동적으로 쓰는 것**"
> 의 차이를 직접 검증하기 위한 비교다.

이는 제안서 v2.0의 "RSI를 state에 포함하면서 RSI 고정 규칙 전략을 베이스라인으로
사용"하는 것과 동일한 논리 구조다. 정보의 출처가 같다고 비교가 불공정해지지 않는다.
오히려 이 비교가 연구의 핵심 질문("학습이 규칙보다 나은가?")을 가장 직접적으로 검증한다.
